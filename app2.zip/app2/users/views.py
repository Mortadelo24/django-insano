from django.shortcuts import render
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect
from django.urls import reverse
# Create your views here.


def index(request):
    if not request.user.is_authenticated:
        return render(request, "users/login.html")
    contex = {
        "user": request.user
    }
    return render(request, "users/index.html", contex)

def login_view(request):
    username = request.POST["username"]
    password = request.POST["password"]

    user = authenticate(request, username = username, password= password)
    if user is not None:
        login(request, user)
        return HttpResponseRedirect(reverse('index'))
    else:
        return render(request, "users/login.html", {"message": "Tu eres false"})


