from django.contrib import admin
from juansapp.models import Vuelo, airport, Passenger
# Register your models here.

admin.site.register(Vuelo)
admin.site.register(airport)
admin.site.register(Passenger)


