from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.shortcuts import render
from juansapp.models import Vuelo, Passenger
from django.urls import reverse

# Create your views here.

def index(request):
    cont = {
        "vuelo": Vuelo.objects.all()


    }


    return render(request, "juansapp/index.html", cont)


def fligts(request, vuelo_id):
    try:
        vuelo1 =   Vuelo.objects.get(pk=vuelo_id)
    except Vuelo.DoesNotExist:
        raise Http404("El vuelo no existe")



    
    cont={
        "info": vuelo1,
        "passengers": list(vuelo1.Passenger.all()),
        "non_passengers": Passenger.objects.exclude(vuelo = vuelo1)
    }
    
    return render(request, "juansapp/vuelo.html", cont)

def book(request, vuelo_id):
    try:
        passenger_id = int(request.POST['passenger'])
        vuelo =  Vuelo.objects.get(pk=vuelo_id)
        passenger = Passenger.objects.get(pk = passenger_id)
    except KeyError:
        return render(request, "juansapp/error.html",{"message":"No se selecciono"} )
    except Vuelo.DoesNotExist:
        return render(request, "juansapp/error.html",{"message":"No se selecciono"} )
    except Passenger.DoesNotExist:
        return render(request, "juansapp/error.html",{"message":"No se selecciono"} )

    passenger.vuelo.add(vuelo)

    return HttpResponseRedirect(reverse("vuelos2", args=(vuelo_id,)))

