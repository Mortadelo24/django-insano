from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("vuelo/<int:vuelo_id>", views.fligts, name = "vuelos2" ),
    path("<int:vuelo_id>/book", views.book, name = "book" )

]
