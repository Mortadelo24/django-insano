from django.db import models

# Create your models here.

class airport(models.Model):
    code = models.CharField(max_length=10)
    city = models.CharField(max_length=20)


    def __str__(self):
        return f"{self.code}{self.city}"

class Vuelo(models.Model):
    origen = models.ForeignKey(airport, on_delete=models.CASCADE, related_name="origen")
    destino = models.ForeignKey(airport, on_delete=models.CASCADE, related_name="destino")
    duration = models.IntegerField()

    def __str__(self):
        return f"{self.origen}{self.destino}{self.duration}"
    


