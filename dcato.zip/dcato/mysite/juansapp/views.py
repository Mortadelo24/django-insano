from django.http import HttpResponse, Http404
from django.shortcuts import render
from juansapp.models import Vuelo

# Create your views here.

def index(request):
    cont = {
        "vuelo": Vuelo.objects.all()


    }


    return render(request, "juansapp/index.html", cont)


def fligts(request, vuelo_id):
    try:
        vuelo =   Vuelo.objects.get(pk=vuelo_id)
    except Vuelo.DoesNotExist:
        raise Http404("El vuelo no existe")



    
    cont={
        "info": vuelo
    }
    
    return render(request, "juansapp/vuelo.html", cont)

