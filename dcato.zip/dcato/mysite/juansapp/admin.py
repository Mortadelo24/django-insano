from django.contrib import admin
from juansapp.models import Vuelo, airport
# Register your models here.

admin.site.register(Vuelo)
admin.site.register(airport)


